// // routes/employeeRoutes.js
// const express = require("express");
// const router = express.Router();
// const auth = require("../middleware/auth");
// const { hrAuth } = require("../middleware/roleMiddleware");
// const Employee = require("../models/Employee");

// router.get("/", auth, hrAuth, async (req, res) => {
//   try {
//     const employees = await Employee.find().select("-password"); // Exclude password field
//     res.status(200).json(employees);
//   } catch (error) {
//     console.error("Error fetching employees:", error);
//     res.status(500).json({ message: "Error fetching employees", error });
//   }
// });

// module.exports = router;

//routes/employeeRoutes
const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth"); // Make sure this file exists and is imported correctly
const Employee = require("../models/Employee");

// Example route
router.get("/", auth, async (req, res) => {
  try {
    const employees = await Employee.find().select("-password"); // Excluding the password field
    res.status(200).json(employees);
  } catch (error) {
    console.error("Error fetching employees:", error);
    res.status(500).json({ message: "Error fetching employees", error });
  }
});

module.exports = router;
