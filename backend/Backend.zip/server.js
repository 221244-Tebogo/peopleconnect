// const express = require("express");
// const mongoose = require("mongoose");
// const bodyParser = require("body-parser");
// const path = require("path");

// const app = express();
// const PORT = process.env.PORT || 5001;

// const cors = require("cors");
// app.use(cors());

// app.use(bodyParser.json());
// app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// const careerRoutes = require("./routes/careerRoutes");
// const employeeRoutes = require("./routes/employeeRoutes");
// const leaveRoutes = require("./routes/leaveRoutes");
// const userRoutes = require("./routes/userRoutes");

// app.use("/api/careers", careerRoutes);
// app.use("/api/employees", employeeRoutes);
// app.use("/api/leaves", leaveRoutes);
// app.use("/api/users", userRoutes);

// mongoose
//   .connect(
//     "mongodb+srv://221244:VLCzVYr1xhEDd4MR@hr-connect.9nbao.mongodb.net/hr-connect?retryWrites=true&w=majority",
//     {
//       useNewUrlParser: true,
//       useUnifiedTopology: true,
//     }
//   )
//   .then(() => console.log("MongoDB connected"))
//   .catch((err) => console.error("MongoDB connection error:", err));

// app.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// });

const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");

// Load environment variables from .env file
dotenv.config();

// Initialize express app
const app = express();

// Middleware
app.use(express.json());
app.use(
  cors({
    origin: "http://localhost:3000", // Adjust to match your frontend URL
    credentials: true,
  })
);

// MongoDB connection
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.error("MongoDB connection error:", err));

// Import routes
const userRoutes = require("./routes/userRoutes");

// Use routes
app.use("/api", userRoutes);

// Start server
const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
