// components/ProtectedRoute.js
import React from "react";
import { Navigate } from "react-router-dom";

const ProtectedRoute = ({ element, allowedRoles, userRole }) => {
  if (!userRole) {
    // Redirect if the user role is not found
    return <Navigate to="/login" replace />;
  }
  return allowedRoles.includes(userRole) ? (
    element
  ) : (
    <Navigate to="/login" replace />
  );
};

export default ProtectedRoute;
