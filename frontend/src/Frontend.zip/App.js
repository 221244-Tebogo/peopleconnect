// src/App.js
import React, { useContext } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute";
import { AuthContext } from "./context/AuthContext";
import "bootstrap/dist/css/bootstrap.min.css";

// Public Pages
import LandingPage from "./pages/LandingPage";
import LoginPage from "./auth/Login";
import RegisterPage from "./auth/Register";
import Logout from "./auth/Logout";
import Post from "./components/Post";

// Employee Pages
import Dashboard from "./pages/employees/Dashboard";
import LeaveManagement from "./pages/employees/LeaveManagement";
import Profile from "./pages/employees/Profile";
import Schedule from "./pages/employees/Schedule";
import Tasks from "./pages/employees/Tasks";
import Training from "./pages/employees/Training";
import Announcements from "./pages/employees/Announcements";
import Career from "./pages/employees/Career";

// Manager Pages
import ManagerDashboard from "./pages/manager/ManagerDashboard";
import ManagerLeaveRequests from "./pages/manager/ManagerLeaveRequests";
import ManagerShiftSchedule from "./pages/manager/ManagerShiftSchedule";
import ManagerReports from "./pages/manager/ManagerReports";
import ManagerProfile from "./pages/manager/ManagerProfile";
import ManagerCareer from "./pages/manager/ManagerCareer";

// HR Pages
import HRMainDashboard from "./pages/hr/HRMainDashboard";
import CreatePost from "./pages/hr/CreatePost";
import LeaveForm from "./pages/hr/LeaveForm";
import SickLeaveForm from "./pages/hr/SickLeaveForm";
import HrAnnouncements from "./pages/hr/HrAnnouncements";
import HrCareer from "./pages/hr/HrCareer";
import HrProfile from "./pages/hr/HrProfile";
import HrRecruitment from "./pages/hr/HrRecruitment";
import HrReporting from "./pages/hr/HrReporting";
import HrTraining from "./pages/hr/HrTraining";
import CreateUser from "./pages/hr/CreateUser";
import AssignTraining from "./pages/hr/AssignTraining";
import EmployeeList from "./pages/hr/EmployeeList";
import ManageLeave from "./pages/hr/ManageLeave";

import "./App.css";

const App = () => {
  // Retrieve the user role from the AuthContext
  const { userRole } = useContext(AuthContext);

  return (
    <Router>
      <div className="app-container">
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/logout" element={<Logout />} />
          <Route path="/post" element={<Post />} />

          {/* Employee Routes */}
          <Route path="/employees/dashboard" element={<Dashboard />}>
            <Route path="leave-management" element={<LeaveManagement />} />
            <Route path="profile" element={<Profile />} />
            <Route path="schedule" element={<Schedule />} />
            <Route path="tasks" element={<Tasks />} />
            <Route path="training" element={<Training />} />
            <Route path="announcements" element={<Announcements />} />
            <Route path="career" element={<Career />} />
          </Route>

          {/* Manager Routes */}
          <Route
            path="/manager/dashboard"
            element={
              <ProtectedRoute
                element={<ManagerDashboard />}
                allowedRoles={["manager"]}
                userRole={userRole}
              />
            }
          />
          <Route
            path="/manager/leave-requests"
            element={
              <ProtectedRoute
                element={<ManagerLeaveRequests />}
                allowedRoles={["manager"]}
                userRole={userRole}
              />
            }
          />
          <Route
            path="/manager/shift-schedule"
            element={
              <ProtectedRoute
                element={<ManagerShiftSchedule />}
                allowedRoles={["manager"]}
                userRole={userRole}
              />
            }
          />
          <Route
            path="/manager/reporting"
            element={
              <ProtectedRoute
                element={<ManagerReports />}
                allowedRoles={["manager"]}
                userRole={userRole}
              />
            }
          />
          <Route
            path="/manager/profile"
            element={
              <ProtectedRoute
                element={<ManagerProfile />}
                allowedRoles={["manager"]}
                userRole={userRole}
              />
            }
          />
          <Route
            path="/manager/career"
            element={
              <ProtectedRoute
                element={<ManagerCareer />}
                allowedRoles={["manager"]}
                userRole={userRole}
              />
            }
          />

          {/* HR Routes */}
          <Route
            path="/hr/HRMainDashboard"
            element={
              <ProtectedRoute
                element={<HRMainDashboard />}
                allowedRoles={["hr"]}
                userRole={userRole}
              />
            }
          >
            <Route path="createpost" element={<CreatePost />} />
            <Route path="leaveform" element={<LeaveForm />} />
            <Route path="sickleaveform" element={<SickLeaveForm />} />
            <Route path="announcements" element={<HrAnnouncements />} />
            <Route path="reporting" element={<HrReporting />} />
            <Route path="recruitment" element={<HrRecruitment />} />
            <Route path="hrtraining" element={<HrTraining />} />
            <Route path="career" element={<HrCareer />} />
            <Route path="profile" element={<HrProfile />} />
            <Route path="createuser" element={<CreateUser />} />
            <Route path="assigntraining" element={<AssignTraining />} />
            <Route
              path="employeelist"
              element={
                <ProtectedRoute
                  element={<EmployeeList />}
                  allowedRoles={["hr"]}
                  userRole={userRole}
                />
              }
            />
            <Route path="manageleave" element={<ManageLeave />} />
          </Route>

          {/* 404 Route */}
          <Route path="*" element={<div>404 Page Not Found</div>} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
